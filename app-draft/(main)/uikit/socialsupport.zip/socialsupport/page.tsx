"use client"
import { InputText } from "primereact/inputtext";
import { RadioButton } from "primereact/radiobutton";
import { useEffect, useState } from "react";
import { Button } from "primereact/button";




import type { Demo, Page } from "@/types";


const SocialSupport: Page = () => {
    const [cd4RadioValue, setCd4RadioValue] = useState(null);
    const [vlRadioValue, setVlRadioValue] = useState(null);
    const [checkboxValue, setCheckboxValue] = useState<string[]>([]);
    const [radioValue1, setRadioValue1] = useState(null);
    const [radioValue2, setRadioValue2] = useState(null);
    const [radioValue3, setRadioValue3] = useState(null);
    const [radioValue4, setRadioValue4] = useState(null);
    const [radioValue5, setRadioValue5] = useState(null);
    const [radioValue6, setRadioValue6] = useState(null);
    const [radioValue7, setRadioValue7] = useState(null);
    const [radioValue8, setRadioValue8] = useState(null);
    const [radioValue9, setRadioValue9] = useState(null);
    const [radioValue10, setRadioValue10] = useState(null);
    const [radioValue11, setRadioValue11] = useState(null);
    const [radioValue12, setRadioValue12] = useState(null);
    const [radioValue13, setRadioValue13] = useState(null);
    const [radioValue14, setRadioValue14] = useState(null);
    const [radioValue15, setRadioValue15] = useState(null);
    const [radioValue16, setRadioValue16] = useState(null);
    const [radioValue17, setRadioValue17] = useState(null);
    const [radioValue18, setRadioValue18] = useState(null);
    const [radioValue19, setRadioValue19] = useState(null);
    const [radioValue20, setRadioValue20] = useState(null);
    const [radioValue21, setRadioValue21] = useState(null);
    const [radioValue22, setRadioValue22] = useState(null);
    const [radioValue23, setRadioValue23] = useState(null);
    const [radioValue24, setRadioValue24] = useState(null);


    const [formState, setFormState] = useState({
        isValid: false,


        touched: {},
        errors: {},
        formValues: {
            insultedFeelings: "",
            belittledHumiliated: "",
            scareIntimidate: "",
            threwOutHouse: "",
            confinedLocked: "",
            threatenedHurt: "",
            slappedThrown: "",
            pushedShoved: "",
            hitWithFist: "",
            kickedDragged: "",
            chokedBurnt: "",
            threatenedUsedWeapon: "",
            forcedSexualIntercourse: "",
            agreedUnwantedIntercourse: "",
            forcedOtherSexualAct: "",
            triedKeepFromFriends: "",
            triedRestrictFamilyContact: "",
            insistedKnowingLocation: "",
            jealousAngryWithMen: "",
            suspiciousUnfaithful: "",
            tookEarningsSavings: "",
            refusedMoneyForHousehold: "",
            triedConvinceCrazy: "",
            blamedForViolentBehavior: ""
        }
    });

    const handleChange = () => {

    }

    const saveSocialSupport = (event: any)=>{
        event.preventDefault();
        
        

        console.log(event)
        
    }

    return (
        <div>       

        <div className="card ">
        <form onSubmit={saveSocialSupport} >
        <h5>Social support </h5>
            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
                1. Insulted you or made you feel bad about yourself? 
                </i> </h6>                       
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient1" name="insultedFeelings" value='Never'
                    checked={radioValue1 === 'Never'}
                    onChange={(e) => {setRadioValue1(e.value)
                        formState.formValues.insultedFeelings = e.target.value
                    console.log(formState)
                    }
                    }  />
                    <label htmlFor="ingredient1" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient2" name="insultedFeelings" value="Once" 
                    onChange={(e) => {setRadioValue1(e.value)
                        formState.formValues.insultedFeelings = e.target.value
                        console.log(formState)
                        }
                        } 
                    checked={radioValue1 === 'Once'} />
                    <label htmlFor="ingredient2" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient3" name="insultedFeelings" value="2-3 Times" 
                    onChange={(e) => {setRadioValue1(e.value)
                        formState.formValues.insultedFeelings = e.target.value
                        console.log(formState)
                        }
                        } 
                         checked={radioValue1 === '2-3 Times'} />
                    <label htmlFor="ingredient3" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient4" name="insultedFeelings" value="4 or more times" 
                    onChange={(e) => {setRadioValue1(e.value)
                    formState.formValues.insultedFeelings = e.target.value
                    console.log(formState)
                    }
                    } 
                    checked={radioValue1 === '4 or more times'} />
                    <label htmlFor="ingredient4" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
               2.  Belittled or humiliated you in front of other people?
                </i> </h6>                     
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="belittledHumiliated" name="belittledHumiliated" value="Never" 
                    onChange={(e) => {setRadioValue2(e.value)
                        formState.formValues.belittledHumiliated = e.target.value
                        console.log(formState)
                        }
                        } 
                         checked={radioValue2 === 'Never'} />
                    <label htmlFor="belittledHumiliated" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="belittledHumiliated" name="belittledHumiliated" value="Once" 
                    onChange={(e) => {setRadioValue2(e.value)
                        formState.formValues.belittledHumiliated = e.target.value
                        console.log(formState)
                        }
                        } 
                    checked={radioValue2 === 'Once'} />
                    <label htmlFor="belittledHumiliated" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="belittledHumiliated" name="belittledHumiliated" value="2-3 Times"
                    onChange={(e) => {setRadioValue2(e.value)
                        formState.formValues.belittledHumiliated = e.target.value
                        console.log(formState)
                        }
                        } 
                    checked={radioValue2 === '2-3 Times'} />
                    <label htmlFor="belittledHumiliated" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="belittledHumiliated" name="belittledHumiliated" value="4 or more times"
                    onChange={(e) => {setRadioValue2(e.value)
                        formState.formValues.belittledHumiliated = e.target.value
                        console.log(formState)
                        }
                        } 
                    checked={radioValue2 === '4 or more times'} />
                    <label htmlFor="belittledHumiliated" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>


           

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
                3. Done things to scare or intimidate you on purpose <br></br>(e.g. by the way he looked at you, by shouting and smashing things)?
                </i> </h6>                
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="scareIntimidate" name="scareIntimidate" value="Never" onChange={(e) => setRadioValue3(e.value)} checked={radioValue3 === 'Never'} />
                    <label htmlFor="scareIntimidate" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="scareIntimidate" name="scareIntimidate" value="Once" onChange={(e) => setRadioValue3(e.value)} checked={radioValue3 === 'Once'} />
                    <label htmlFor="scareIntimidate" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="scareIntimidate" name="scareIntimidate" value="2-3 Times" onChange={(e) => setRadioValue3(e.value)} checked={radioValue3 === '2-3 Times'} />
                    <label htmlFor="scareIntimidate" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="scareIntimidate" name="scareIntimidate" value="4 or more times" onChange={(e) => setRadioValue3(e.value)} checked={radioValue3 === '4 or more times'} />
                    <label htmlFor="scareIntimidate" className="ml-2">4 or more times</label>
                </div>
            </div>

            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
                4. Threw you out of the house or made you find a new place to stay?    
                </i> </h6>                     
                </div>
                        
              
                
                <div className="flex align-items-center">
                    <RadioButton inputId="scareIntimidate" name="insultedFeelings" value="Never" onChange={(e) => setRadioValue4(e.value)} checked={radioValue4 === 'Never'} />
                    <label htmlFor="scareIntimidate" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient2" name="insultedFeelings" value="Once" onChange={(e) => setRadioValue4(e.value)} checked={radioValue4 === 'Once'} />
                    <label htmlFor="ingredient2" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient3" name="insultedFeelings" value="2-3 Times" onChange={(e) => setRadioValue4(e.value)} checked={radioValue4 === '2-3 Times'} />
                    <label htmlFor="ingredient3" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient4" name="insultedFeelings" value="4 or more times" onChange={(e) => setRadioValue4(e.value)} checked={radioValue4 === '4 or more times'} />
                    <label htmlFor="ingredient4" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
               5. Confined or locked you in a room or other space?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="scareIntimidate" name="confinedLocked" value="Never" onChange={(e) => setRadioValue5(e.value)} checked={radioValue5 === 'Never'} />
                    <label htmlFor="ingredient1" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient2" name="confinedLocked" value="Once" onChange={(e) => setRadioValue5(e.value)} checked={radioValue5 === 'Once'} />
                    <label htmlFor="ingredient2" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient3" name="confinedLocked" value="2-3 Times" onChange={(e) => setRadioValue5(e.value)} checked={radioValue5 === '2-3 Times'} />
                    <label htmlFor="ingredient3" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient4" name="confinedLocked" value="4 or more times" onChange={(e) => setRadioValue5(e.value)} checked={radioValue5 === '4 or more times'} />
                    <label htmlFor="ingredient4" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
               6. Threatened to hurt you or someone you care about?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="threatenedHurt" name="threatenedHurt" value="Never" onChange={(e) => setRadioValue6(e.value)} checked={radioValue6 === 'Never'} />
                    <label htmlFor="threatenedHurt" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="threatenedHurt" name="threatenedHurt" value="Once" onChange={(e) => setRadioValue6(e.value)} checked={radioValue6 === 'Once'} />
                    <label htmlFor="threatenedHurt" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="threatenedHurt" name="threatenedHurt" value="2-3 Times" onChange={(e) => setRadioValue6(e.value)} checked={radioValue6 === '2-3 Times'} />
                    <label htmlFor="threatenedHurt" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="threatenedHurt" name="threatenedHurt" value="4 or more times" onChange={(e) => setRadioValue6(e.value)} checked={radioValue6 === '4 or more times'} />
                    <label htmlFor="threatenedHurt" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                7. Slapped you or thrown something at you that could hurt you?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="slappedThrown" name="slappedThrown" value="Never" onChange={(e) => setRadioValue7(e.value)} checked={radioValue7 === 'Never'} />
                    <label htmlFor="slappedThrown" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="slappedThrown" name="slappedThrown" value="Once" onChange={(e) => setRadioValue7(e.value)} checked={radioValue7 === 'Once'} />
                    <label htmlFor="slappedThrown" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="slappedThrown" name="slappedThrown" value="2-3 Times" onChange={(e) => setRadioValue7(e.value)} checked={radioValue7 === '2-3 Times'} />
                    <label htmlFor="threatenedHurt" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="slappedThrown" name="slappedThrown" value="4 or more times" onChange={(e) => setRadioValue7(e.value)} checked={radioValue7 === '4 or more times'} />
                    <label htmlFor="slappedThrown" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                8. Pushed you or shoved you or pulled your hair?
                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="pushedShoved" name="pushedShoved" value="Never" onChange={(e) => setRadioValue8(e.value)} checked={radioValue8 === 'Never'} />
                    <label htmlFor="pushedShoved" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="pushedShoved" name="pushedShoved" value="Once" onChange={(e) => setRadioValue8(e.value)} checked={radioValue8 === 'Once'} />
                    <label htmlFor="pushedShoved" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="pushedShoved" name="pushedShoved" value="2-3 Times" onChange={(e) => setRadioValue8(e.value)} checked={radioValue8 === '2-3 Times'} />
                    <label htmlFor="pushedShoved" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="pushedShoved" name="pushedShoved" value="4 or more times" onChange={(e) => setRadioValue8(e.value)} checked={radioValue8 === '4 or more times'} />
                    <label htmlFor="pushedShoved" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                9. Hit you with his fist or with something else that could hurt you?
                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient1" name="hitWithFist" value="Never" onChange={(e) => setRadioValue9(e.value)} checked={radioValue9 === 'Never'} />
                    <label htmlFor="hitWithFist" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="hitWithFist" name="hitWithFist" value="Once" onChange={(e) => setRadioValue9(e.value)} checked={radioValue9 === 'Once'} />
                    <label htmlFor="hitWithFist" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="hitWithFist" name="hitWithFist" value="2-3 Times" onChange={(e) => setRadioValue9(e.value)} checked={radioValue9 === '2-3 Times'} />
                    <label htmlFor="hitWithFist" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="hitWithFist" name="hitWithFist" value="4 or more times" onChange={(e) => setRadioValue9(e.value)} checked={radioValue9 === '4 or more times'} />
                    <label htmlFor="hitWithFist" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                10. Kicked you, dragged you or beaten you up?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="kickedDragged" name="kickedDragged" value="Never" onChange={(e) => setRadioValue10(e.value)} checked={radioValue10 === 'Never'} />
                    <label htmlFor="kickedDragged" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="kickedDragged" name="kickedDragged" value="Once" onChange={(e) => setRadioValue10(e.value)} checked={radioValue10 === 'Once'} />
                    <label htmlFor="kickedDragged" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="kickedDragged" name="kickedDragged" value="2-3 Times" onChange={(e) => setRadioValue10(e.value)} checked={radioValue10 === '2-3 Times'} />
                    <label htmlFor="kickedDragged" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="kickedDragged" name="kickedDragged" value="4 or more times" onChange={(e) => setRadioValue10(e.value)} checked={radioValue10 === '4 or more times'} />
                    <label htmlFor="kickedDragged" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                11. Choked or burnt you on purpose?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="ingredient1" name="chokedBurnt" value="Never" onChange={(e) => setRadioValue11(e.value)} checked={radioValue11 === 'Never'} />
                    <label htmlFor="chokedBurnt" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="chokedBurnt" name="chokedBurnt" value="Once" onChange={(e) => setRadioValue11(e.value)} checked={radioValue11 === 'Once'} />
                    <label htmlFor="chokedBurnt" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="chokedBurnt" name="chokedBurnt" value="2-3 Times" onChange={(e) => setRadioValue11(e.value)} checked={radioValue11 === '2-3 Times'} />
                    <label htmlFor="chokedBurnt" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="chokedBurnt" name="chokedBurnt" value="4 or more times" onChange={(e) => setRadioValue11(e.value)} checked={radioValue11 === '4 or more times'} />
                    <label htmlFor="chokedBurnt" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                12. Threatened to use or actually used a gun, knife or other weapon against you?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="threatenedUsedWeapon" name="threatenedUsedWeapon" value="Never" onChange={(e) => setRadioValue12(e.value)} checked={radioValue12 === 'Never'} />
                    <label htmlFor="threatenedUsedWeapon" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="threatenedUsedWeapon" name="threatenedUsedWeapon" value="Once" onChange={(e) => setRadioValue12(e.value)} checked={radioValue12 === 'Once'} />
                    <label htmlFor="threatenedUsedWeapon" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="threatenedUsedWeapon" name="threatenedUsedWeapon" value="2-3 Times" onChange={(e) => setRadioValue12(e.value)} checked={radioValue12 === '2-3 Times'} />
                    <label htmlFor="threatenedUsedWeapon" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="threatenedUsedWeapon" name="threatenedUsedWeapon" value="4 or more times" onChange={(e) => setRadioValue12(e.value)} checked={radioValue12 === '4 or more times'} />
                    <label htmlFor="threatenedUsedWeapon" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                13. Force you to have sexual intercourse by threatening you, holding you down or hurting you in some way?


                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="forcedSexualIntercourse" name="forcedSexualIntercourse" value="Never" onChange={(e) => setRadioValue13(e.value)} checked={radioValue13 === 'Never'} />
                    <label htmlFor="forcedSexualIntercourse" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="forcedSexualIntercourse" name="forcedSexualIntercourse" value="Once" onChange={(e) => setRadioValue13(e.value)} checked={radioValue13 === 'Once'} />
                    <label htmlFor="forcedSexualIntercourse" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="forcedSexualIntercourse" name="forcedSexualIntercourse" value="2-3 Times" onChange={(e) => setRadioValue13(e.value)} checked={radioValue13 === '2-3 Times'} />
                    <label htmlFor="forcedSexualIntercourse" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="forcedSexualIntercourse" name="forcedSexualIntercourse" value="4 or more times" onChange={(e) => setRadioValue13(e.value)} checked={radioValue13 === '4 or more times'} />
                    <label htmlFor="forcedSexualIntercourse" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                14. Did you ever agree to have intercourse when you did not want to because you were afraid of what your husband/partner might do if you refused?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="agreedUnwantedIntercourse" name="agreedUnwantedIntercourse" value="Never" onChange={(e) => setRadioValue14(e.value)} checked={radioValue14 === 'Never'} />
                    <label htmlFor="agreedUnwantedIntercourse" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="agreedUnwantedIntercourse" name="agreedUnwantedIntercourse" value="Once" onChange={(e) => setRadioValue14(e.value)} checked={radioValue14 === 'Once'} />
                    <label htmlFor="agreedUnwantedIntercourse" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="agreedUnwantedIntercourse" name="agreedUnwantedIntercourse" value="2-3 Times" onChange={(e) => setRadioValue14(e.value)} checked={radioValue14 === '2-3 Times'} />
                    <label htmlFor="agreedUnwantedIntercourse" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="agreedUnwantedIntercourse" name="agreedUnwantedIntercourse" value="4 or more times" onChange={(e) => setRadioValue14(e.value)} checked={radioValue14 === '4 or more times'} />
                    <label htmlFor="agreedUnwantedIntercourse" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                15. Force you to do something sexual (besides vaginal intercourse) that you did not want to do?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="forcedOtherSexualAct" name="forcedOtherSexualAct" value="Never" onChange={(e) => setRadioValue15(e.value)} checked={radioValue15 === 'Never'} />
                    <label htmlFor="forcedOtherSexualAct" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="forcedOtherSexualAct" name="forcedOtherSexualAct" value="Once" onChange={(e) => setRadioValue15(e.value)} checked={radioValue15 === 'Once'} />
                    <label htmlFor="forcedOtherSexualAct" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="forcedOtherSexualAct" name="forcedOtherSexualAct" value="2-3 Times" onChange={(e) => setRadioValue15(e.value)} checked={radioValue15 === '2-3 Times'} />
                    <label htmlFor="forcedOtherSexualAct" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="forcedOtherSexualAct" name="forcedOtherSexualAct" value="4 or more times" onChange={(e) => setRadioValue15(e.value)} checked={radioValue15 === '4 or more times'} />
                    <label htmlFor="forcedOtherSexualAct" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                16. Tried to keep you from seeing your friends?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="triedKeepFromFriends" name="triedKeepFromFriends" value="Never" onChange={(e) => setRadioValue16(e.value)} checked={radioValue16 === 'Never'} />
                    <label htmlFor="triedKeepFromFriends" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedKeepFromFriends" name="triedKeepFromFriends" value="Once" onChange={(e) => setRadioValue16(e.value)} checked={radioValue16 === 'Once'} />
                    <label htmlFor="triedKeepFromFriends" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedKeepFromFriends" name="triedKeepFromFriends" value="2-3 Times" onChange={(e) => setRadioValue16(e.value)} checked={radioValue16 === '2-3 Times'} />
                    <label htmlFor="triedKeepFromFriends" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedKeepFromFriends" name="triedKeepFromFriends" value="4 or more times" onChange={(e) => setRadioValue16(e.value)} checked={radioValue16 === '4 or more times'} />
                    <label htmlFor="triedKeepFromFriends" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                17. Tried to restrict contact with your family of birth?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="triedRestrictFamilyContact" name="triedRestrictFamilyContact" value="Never" onChange={(e) => setRadioValue17(e.value)} checked={radioValue17 === 'Never'} />
                    <label htmlFor="triedRestrictFamilyContact" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedRestrictFamilyContact" name="triedRestrictFamilyContact" value="Once" onChange={(e) => setRadioValue17(e.value)} checked={radioValue17 === 'Once'} />
                    <label htmlFor="triedRestrictFamilyContact" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedRestrictFamilyContact" name="triedRestrictFamilyContact" value="2-3 Times" onChange={(e) => setRadioValue17(e.value)} checked={radioValue17 === '2-3 Times'} />
                    <label htmlFor="triedRestrictFamilyContact" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedRestrictFamilyContact" name="triedRestrictFamilyContact" value="4 or more times" onChange={(e) => setRadioValue17(e.value)} checked={radioValue17 === '4 or more times'} />
                    <label htmlFor="triedRestrictFamilyContact" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                18. Insisted on knowing where you are at all times?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="insistedKnowingLocation" name="insistedKnowingLocation" value="Never" onChange={(e) => setRadioValue18(e.value)} checked={radioValue18 === 'Never'} />
                    <label htmlFor="insistedKnowingLocation" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="insistedKnowingLocation" name="insistedKnowingLocation" value="Once" onChange={(e) => setRadioValue18(e.value)} checked={radioValue18 === 'Once'} />
                    <label htmlFor="insistedKnowingLocation" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="insistedKnowingLocation" name="insistedKnowingLocation" value="2-3 Times" onChange={(e) => setRadioValue18(e.value)} checked={radioValue18 === '2-3 Times'} />
                    <label htmlFor="insistedKnowingLocation" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="insistedKnowingLocation" name="insistedKnowingLocation" value="4 or more times" onChange={(e) => setRadioValue18(e.value)} checked={radioValue18 === '4 or more times'} />
                    <label htmlFor="insistedKnowingLocation" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
               <h6><i>
                19. Been jealous or angry if you spoke with other men?

                </i> </h6>                      
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="jealousAngryWithMen" name="jealousAngryWithMen" value="Never" onChange={(e) => setRadioValue19(e.value)} checked={radioValue19 === 'Never'} />
                    <label htmlFor="jealousAngryWithMen" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="jealousAngryWithMen" name="jealousAngryWithMen" value="Once" onChange={(e) => setRadioValue19(e.value)} checked={radioValue19 === 'Once'} />
                    <label htmlFor="jealousAngryWithMen" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="jealousAngryWithMen" name="jealousAngryWithMen" value="2-3 Times" onChange={(e) => setRadioValue19(e.value)} checked={radioValue19 === '2-3 Times'} />
                    <label htmlFor="jealousAngryWithMen" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="jealousAngryWithMen" name="jealousAngryWithMen" value="4 or more times" onChange={(e) => setRadioValue19(e.value)} checked={radioValue19 === '4 or more times'} />
                    <label htmlFor="ingrediejealousAngryWithMennt4" className="ml-2">4 or more times</label>
                </div>
            </div>
            <br></br>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
                20. Was suspicious that you were unfaithful even when you were being faithful?
                    
                    </i> </h6>            
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="suspiciousUnfaithful" name="suspiciousUnfaithful" value="Never" onChange={(e) => setRadioValue20(e.value)} checked={radioValue20 === 'Never'} />
                    <label htmlFor="suspiciousUnfaithful" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="suspiciousUnfaithful" name="suspiciousUnfaithful" value="Once" onChange={(e) => setRadioValue20(e.value)} checked={radioValue20 === 'Once'} />
                    <label htmlFor="suspiciousUnfaithful" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="suspiciousUnfaithful" name="suspiciousUnfaithful" value="2-3 Times" onChange={(e) => setRadioValue20(e.value)} checked={radioValue20 === '2-3 Times'} />
                    <label htmlFor="suspiciousUnfaithful" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="suspiciousUnfaithful" name="suspiciousUnfaithful" value="4 or more times" onChange={(e) => setRadioValue20(e.value)} checked={radioValue20 === '4 or more times'} />
                    <label htmlFor="suspiciousUnfaithful" className="ml-2">4 or more times</label>
                </div>
            </div>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
                    21. Took your earnings or savings against your will?
                    
                    </i> </h6>            
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="tookEarningsSavings" name="tookEarningsSavings" value="Never" onChange={(e) => setRadioValue21(e.value)} checked={radioValue21 === 'Never'} />
                    <label htmlFor="tookEarningsSavings" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="tookEarningsSavings" name="tookEarningsSavings" value="Once" onChange={(e) => setRadioValue21(e.value)} checked={radioValue21 === 'Once'} />
                    <label htmlFor="tookEarningsSavings" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="tookEarningsSavings" name="tookEarningsSavings" value="2-3 Times" onChange={(e) => setRadioValue21(e.value)} checked={radioValue21 === '2-3 Times'} />
                    <label htmlFor="tookEarningsSavings" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="tookEarningsSavings" name="tookEarningsSavings" value="4 or more times" onChange={(e) => setRadioValue21(e.value)} checked={radioValue21 === '4 or more times'} />
                    <label htmlFor="tookEarningsSavings" className="ml-2">4 or more times</label>
                </div>
            </div>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
                    22. Refused to give money for household even when he has money for other things?
                    </i> </h6>            
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="refusedMoneyForHousehold" name="refusedMoneyForHousehold" value="Never" onChange={(e) => setRadioValue22(e.value)} checked={radioValue22 === 'Never'} />
                    <label htmlFor="refusedMoneyForHousehold" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="refusedMoneyForHousehold" name="refusedMoneyForHousehold" value="Once" onChange={(e) => setRadioValue22(e.value)} checked={radioValue22 === 'Once'} />
                    <label htmlFor="refusedMoneyForHousehold" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="refusedMoneyForHousehold" name="refusedMoneyForHousehold" value="2-3 Times" onChange={(e) => setRadioValue22(e.value)} checked={radioValue22 === '2-3 Times'} />
                    <label htmlFor="refusedMoneyForHousehold" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="refusedMoneyForHousehold" name="refusedMoneyForHousehold" value="4 or more times" onChange={(e) => setRadioValue22(e.value)} checked={radioValue22 === '4 or more times'} />
                    <label htmlFor="refusedMoneyForHousehold" className="ml-2">4 or more times</label>
                </div>
            </div>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
                    23. Tried to convince your family, children or friends that you are crazy or tried to turn them against you?
                    </i> </h6>            
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="triedConvinceCrazy" name="triedConvinceCrazy" value="Never" onChange={(e) => setRadioValue23(e.value)} checked={radioValue23 === 'Never'} />
                    <label htmlFor="triedConvinceCrazy" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedConvinceCrazy" name="triedConvinceCrazy" value="Once" onChange={(e) => setRadioValue23(e.value)} checked={radioValue23 === 'Once'} />
                    <label htmlFor="triedConvinceCrazy" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedConvinceCrazy" name="triedConvinceCrazy" value="2-3 Times" onChange={(e) => setRadioValue23(e.value)} checked={radioValue23 === '2-3 Times'} />
                    <label htmlFor="triedConvinceCrazy" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="triedConvinceCrazy" name="triedConvinceCrazy" value="4 or more times" onChange={(e) => setRadioValue23(e.value)} checked={radioValue23 === '4 or more times'} />
                    <label htmlFor="triedConvinceCrazy" className="ml-2">4 or more times</label>
                </div>
            </div>

            <div className="flex flex-wrap gap-3">
                <div className="flex align-items-center">
                <h6><i>
                    24. Blamed you for causing their violent behaviour?
                    </i> </h6>            
                </div>
                
                <div className="flex align-items-center">
                    <RadioButton inputId="blamedForViolentBehavior" name="blamedForViolentBehavior" value="Never" onChange={(e) => setRadioValue24(e.value)} checked={radioValue24 === 'Never'} />
                    <label htmlFor="blamedForViolentBehavior" className="ml-2">Never</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="blamedForViolentBehavior" name="blamedForViolentBehavior" value="Once" onChange={(e) => setRadioValue24(e.value)} checked={radioValue24 === 'Once'} />
                    <label htmlFor="blamedForViolentBehavior" className="ml-2">Once</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="blamedForViolentBehavior" name="blamedForViolentBehavior" value="2-3 Times" onChange={(e) => setRadioValue24(e.value)} checked={radioValue24 === '2-3 Times'} />
                    <label htmlFor="blamedForViolentBehavior" className="ml-2">2-3 Times</label>
                </div>
                <div className="flex align-items-center">
                    <RadioButton inputId="blamedForViolentBehavior" name="blamedForViolentBehavior" value="4 or more times" onChange={(e) => setRadioValue24(e.value)} checked={radioValue24 === '4 or more times'} />
                    <label htmlFor="blamedForViolentBehavior" className="ml-2">4 or more times</label>
                </div>
            </div>

            <div className="field col-12 md:col-6">
                            <label htmlFor="otherNames">..</label>
                            <Button label="Search" icon="pi pi-save"  type="submit" />
                        </div>
            </form>
        </div>
        </div>

        
       
    )
}

export default SocialSupport